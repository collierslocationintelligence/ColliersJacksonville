define({
  "commonMapControls": {
    "common": {
      "settings": "Nastavení",
      "openDefault": "Otevřít jako výchozí"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Podkladová mapa",
      "expandFactorLabel": "Faktor rozšíření",
      "expandFactorPopover": "Poměr mezi velikostí přehledové mapy a obdélníkem rozsahu zobrazeným na přehledové mapě. Výchozí hodnota je 2, což znamená, že přehledová mapa má minimálně dvakrát větší rozsah, než je rozsah vlastní mapy."
    }
  }
});