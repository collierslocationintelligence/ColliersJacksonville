define({
  "commonMapControls": {
    "common": {
      "settings": "Configuració",
      "openDefault": "Obre per defecte"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Mapa base",
      "expandFactorLabel": "Factor d'ampliació",
      "expandFactorPopover": "Relació entre la mida del mapa de visualització general i el rectangle d'extensió que s'hi mostra. El valor per defecte és 2 i significa que el mapa de visualització general serà almenys el doble de gran que el rectangle d'extensió."
    }
  }
});