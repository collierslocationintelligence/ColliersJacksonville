define({
  "commonMapControls": {
    "common": {
      "settings": "Iestatījumi",
      "openDefault": "Atvērt pēc noklusējuma"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Pamatkarte",
      "expandFactorLabel": "Izvēršanas koeficients",
      "expandFactorPopover": "Proporcija starp pārskata kartes lielumu un pārskata kartē attēloto pārklājuma taisnstūri. Noklusējuma vērtība ir 2. Tas nozīmē, ka pārskata karte būs vismaz divas reizes lielāka par pārklājuma taisnstūri."
    }
  }
});