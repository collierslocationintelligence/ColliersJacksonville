define({
  "commonMapControls": {
    "common": {
      "settings": "Beállítások",
      "openDefault": "Megnyitás alapértelmezés szerint"
    },
    "overview": {
      "basemapGalleryBtnLabel": "Alaptérkép",
      "expandFactorLabel": "Kibontási tényező",
      "expandFactorPopover": "Az átnézeti térkép méretének és az átnézeti térképen megjelenített négyszöges kiterjedés méretének aránya. Az alapértelmezett érték 2, ami azt jelenti, hogy az átnézeti térkép mérete legalább kétszer akkora lesz, mint a négyszöges kiterjedés mérete."
    }
  }
});