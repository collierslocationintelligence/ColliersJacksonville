define({
  "viewer": {
    "common": {
      "close": "Bezárás",
      "focusMainstage": "Billentyűzetfókusz küldése a médiára",
      "expandImage": "Kép kibontása"
    },
    "a11y": {
      "skipToContent": "Ugrás a tartalomhoz",
      "headerAria": "Történet fejléce",
      "panelAria": "Történet tartalmának megjelenítése",
      "mainStageAria": "Média a történet aktuális szekciójában",
      "logoLinkAria": "Logó hivatkozása",
      "toTop": "Ugrás az első bejegyzéshez",
      "focusContent": "Vissza a tartalomhoz",
      "navAria": "Történetbejegyzések",
      "toEntryAria": "Ugrás a következő bejegyzéshez: %ENTRY_NUMBER%: %ENTRY_TITLE%",
      "entryAria": "Bejegyzés: %ENTRY_NUMBER%: %ENTRY_TITLE%",
      "loadingAria": "A történet tartalmának betöltése folyamatban van",
      "skipBelowContent": "Ugrás a tartalom alá",
      "skipBelowVideo": "Ugrás a video alá",
      "skipAboveContent": "Ugrás a tartalom fölé",
      "skipAboveVideo": "Ugrás a videó fölé",
      "moreEntries": "Több bejegyzés"
    },
    "loading": {
      "long": "A történet inicializálása folyamatban van",
      "long2": "Kérjük, várjon",
      "failButton": "Történet újbóli betöltése"
    },
    "signin": {
      "title": "Hitelesítés szükséges",
      "explainViewer": "Jelentkezzen be egy fiókkal a(z) %PORTAL_LINK% portálon a történet eléréséhez.",
      "explainBuilder": "Jelentkezzen be egy fiókkal a(z) %PORTAL_LINK% portálon a történet konfigurálásához."
    },
    "errors": {
      "boxTitle": "Hiba történt",
      "invalidConfig": "Érvénytelen konfiguráció",
      "invalidConfigNoApp": "A Webes térképkészítő alkalmazás azonosítója nincs megadva az index.html fájlban.",
      "invalidConfigNoAppDev": "A Webes térképkészítő alkalmazás azonosítója nincs megadva az URL paramétereiben (?appid=). Fejlesztői módban az index.html fájlban található appid konfiguráció figyelmen kívül van hagyva.",
      "unspecifiedConfigOwner": "Nincs konfigurálva jogosult tulajdonos.",
      "invalidConfigOwner": "Nincs jogosultsága a történet tulajdonosának",
      "createMap": "Nem sikerült létrehozni a térképet",
      "invalidApp": "A(z) %TPL_NAME% nem létezik vagy nem érhető el.",
      "appLoadingFail": "Hiba történt, a(z) %TPL_NAME% nem töltődött be megfelelően.",
      "notConfiguredDesktop": "A történet még nincs konfigurálva.",
      "notConfiguredMobile": "A(z) %TPL_NAME% szerkesztő nem támogatott ennél a kijelzőméretnél. Ha lehetséges, módosítsa a böngésző méretét úgy, hogy elérhető legyen a szerkesztő, vagy használjon nagyobb képernyővel rendelkező eszközt a történet összeállításához.",
      "notConfiguredMobile2": "A(z) %TPL_NAME% szerkesztő használatához fordítsa el fekvő tájolásra az eszközt.",
      "notAuthorized": "Ön nem jogosult a történet elérésére",
      "notAuthorizedBuilder": "Ön nem jogosult a(z) %TPL_NAME% szerkesztő használatára.",
      "noBuilderIE": "A szerkesztő nem támogatott a(z) %VERSION% verzió előtti Internet Explorerben. %UPGRADE%",
      "noViewerIE": "Ez a történet nem támogatott a(z) %VERSION% verzió előtti Internet Explorerben. %UPGRADE%",
      "noViewerIE2": "Ezt a történetet egy régebbi, nem támogatott böngészőben próbálja megtekinteni. Előfordulhat, hogy néhány vektoros elem nem fog megfelelően működni, vagy váratlan hibák történhetnek. Azt javasoljuk, hogy frissítsen az Internet Explorer 11-es verziójára, vagy használjon más böngészőt, például a Chrome-ot.",
      "noViewerIE3": "2017 végén ez a történet már nem töltődik be ebben a böngészőben. A történet megtekintéséhez támogatott böngészőt kell használnia.",
      "upgradeBrowser": "<a href='http://browsehappy.com/' target='_blank'>Frissítse a böngészőjét</a>.",
      "mapLoadingFail": "Hiba történt, a térkép nem töltődött be megfelelően.",
      "signOut": "Kijelentkezés",
      "attention": "Figyelem!"
    },
    "mainStage": {
      "back": "Vissza",
      "errorDeleted": "Ez a hivatkozás nem aktív (a szekció törölve lett)",
      "errorNotPublished": "Ez a hivatkozás nem aktív (a szekció nincs közzétéve)"
    },
    "panel": {
      "collapse": "Panel összecsukása",
      "expand": "Panel kibontása"
    },
    "mobileInfo": {
      "legend": "Jelmagyarázat",
      "description": "Leírás",
      "lblLegendMobileError": "A jelmagyarázat nem érhető el. Töltse be újból a történetet.",
      "lblLegendMobileErrorExplain": "A jelmagyarázat nem érhető el, ha az eszközt álló tájolásba fordítja a történet betöltése után."
    },
    "mobileFooter": {
      "swipeInvite": "Pöccintsen a történet navigálásához",
      "lblNext": "Következő",
      "lblEnd": "A történet végéhez ért"
    },
    "headerFromCommon": {
      "storymapsText": "Egy story map",
      "builderButton": "Szerkesztés",
      "facebookTooltip": "Megosztás Facebookon",
      "twitterTooltip": "Megosztás Twitteren",
      "bitlyTooltip": "Rövid hivatkozás lekérése",
      "templateTitle": "Sablon címének beállítása",
      "templateSubtitle": "Sablon alcímének beállítása",
      "share": "Megosztás",
      "checking": "A történet tartalmának ellenőrzése",
      "fix": "Javítsa ki a történetben lévő hibákat",
      "noerrors": "Nincs probléma",
      "tooltipAutoplayDisabled": "Ez nem érhető el automatikus lejátszási módban",
      "notshared": "A történet nem megosztott"
    },
    "mapFromCommon": {
      "overview": "Átnézeti térkép",
      "legend": "Jelmagyarázat",
      "home": "Kezdőlap nagyítása/kicsinyítése"
    },
    "shareFromCommon": {
      "copy": "Másolás",
      "copied": "Másolt",
      "open": "Megnyitás",
      "embed": "Beágyazás weboldalon",
      "embedExplain": "A következő HTML-kód használatával ágyazhatja be a történetet a weboldalakon.",
      "size": "Méret (szélesség/magasság):",
      "autoplayLabel": "Automatikus lejátszási mód",
      "autoplayExplain1": "Az automatikus lejátszási mód meghatározott időközönként léptetve halad végig a történeten. Ez ideális megoldás a nyilvános monitorokon történő megjelenítéshez, de vegye figyelembe, hogy más helyzetekben megnehezítheti a történet olvasását. Ez a funkció kisméretű kijelzőkön nem támogatott.",
      "autoplayExplain2": "Amikor aktív ez a mód, vezérlők érhetők el a történet lejátszásához/szüneteltetéséhez, valamint a navigáció sebességének beállításához.",
      "linksupdated": "A hivatkozások frissítése megtörtént."
    },
    "locatorFromCommon": {
      "error": "A hely nem érhető el"
    }
  }
});